package com.example.movie;



public class FeatureModel {

    private String Fcast;
    private String Fcover;
    private String Fds;
    private String Flink;
    private String Fthumb;
    private String Ftitle;
    private String Tlink;

    public FeatureModel() {
    }

    public FeatureModel(String fcast, String fcover, String fds, String flink, String fthumb, String ftitle, String tlink) {
        Fcast = fcast;
        Fcover = fcover;
        Fds = fds;
        Flink = flink;
        Fthumb = fthumb;
        Ftitle = ftitle;
        Tlink = tlink;
    }

    public String getFcast() {
        return Fcast;
    }

    public void setFcast(String fcast) {
        Fcast = fcast;
    }

    public String getFcover() {
        return Fcover;
    }

    public void setFcover(String fcover) {
        Fcover = fcover;
    }

    public String getFds() {
        return Fds;
    }

    public void setFds(String fds) {
        Fds = fds;
    }

    public String getFlink() {
        return Flink;
    }

    public void setFlink(String flink) {
        Flink = flink;
    }

    public String getFthumb() {
        return Fthumb;
    }

    public void setFthumb(String fthumb) {
        Fthumb = fthumb;
    }

    public String getFtitle() {
        return Ftitle;
    }

    public void setFtitle(String ftitle) {
        Ftitle = ftitle;
    }

    public String getTlink() {
        return Tlink;
    }

    public void setTlink(String tlink) {
        Tlink = tlink;
    }
}
